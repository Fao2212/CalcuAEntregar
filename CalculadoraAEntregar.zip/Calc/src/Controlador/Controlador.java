/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;
    
import GUI.FormFrame;
import GUI.Pantalla;
import TDA.Calculadora;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Arrays;
import javax.swing.JButton;
import TDA.Calculadora.Modo;

/**
 *
 * @author Fernando Alvarez
 */
public class Controlador implements KeyListener, ActionListener{
    
    private Pantalla pantalla;
    private Calculadora calculadora;
    private char operando;
    
    public Controlador(){
        this.pantalla = new Pantalla();
        this.calculadora = new Calculadora();
        this.operando = Character.MIN_VALUE;
        this.pantalla.setVisible(true);
        initListeners();
    }

    private void initListeners(){
        pantalla.setFocusable(true);
        pantalla.addKeyListener(this);
        for (int i = 0; i < pantalla.botones.length; i++) {
            pantalla.botones[i].addActionListener(this);
            pantalla.botones[i].setFocusable(false);
        }
    }
    
    @Override
    public void keyTyped(KeyEvent e) {

    }    

    @Override
    public void keyPressed(KeyEvent e) {
            char caracter = e.getKeyChar();
            int keyCode = e.getKeyCode();
            if(isWritable(caracter))
                pantalla.setText(caracter);
            else if(isOperation(caracter))
                operation(caracter);
            else{
                switch(keyCode){
                    case KeyEvent.VK_BACK_SPACE:
                        pantalla.backSapce();
                        break;
                    case KeyEvent.VK_ENTER:
                        equal();
                        break;
                    case KeyEvent.VK_CONTROL:
                        clear();
                        break;
                }
            }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        
    }
    private void setModo(Modo modo){
        calculadora.setOperando1("");
        calculadora.setResultado("");
        pantalla.clear(); 
        calculadora.setModo(modo);
        clearOperando();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if(source.equals(pantalla.btnMemoria))
            memory();
        else if(source.equals(pantalla.btnPromedio)){
            pantalla.clear();
            String impresion = (calculadora.promedio());
            agregarABitacora("Promedio: "+ impresion);
        }
        else if(source.equals(pantalla.btnBinario)){
            setModo(Modo.BINARIO);
            desactivarBotones(pantalla.botonesOperando);
        }
        else if(source.equals(pantalla.btnDecimal)){
            setModo(Modo.DECIMAL);
            activarBotones(pantalla.botonesOperando);
        }
        else if(source.equals(pantalla.btnPrimo)){
            setModo(Modo.PRIMO);
            desactivarBotones(pantalla.botonesOperando);
        }
        else if(source.equals(pantalla.btnEquals))
            equal();
        else if(source.equals(pantalla.btnBitacora)){
            FormFrame frameBitacora = new FormFrame(calculadora.getBitacora().getMensaje());
            frameBitacora.setVisible(true);
        }
        else if(isNumberButton((JButton)source )){
            JButton boton = (JButton)source;
            pantalla.setText(getButtonIndex(boton));
        }
        else if(isOperandoButton((JButton)source)){
            JButton boton = (JButton)source;
            operation(boton.getText().charAt(0));
        }
        else if(source.equals(pantalla.btnC)){
            clear();
        }
        else if(source.equals(pantalla.btnPoint))
            pantalla.setText('.');
    }
    
    private boolean isOperandoButton(JButton source){
        for (JButton boton : pantalla.botonesOperando) {
            if(boton == source)
                return true;
        }
        return false; 
    }
    
    private boolean isNumberButton(JButton botoneta){
        for (JButton boton : pantalla.botonesNumeros) {
            if(boton == botoneta)
                return true;
        }
        return false;
    }
    
    private int getButtonIndex(JButton botoneta){
        for (int i = 0;i < pantalla.botonesNumeros.length;i++) {
            JButton boton = pantalla.botonesNumeros[i];
            if(boton == botoneta)
                return i;
        }
        return -1;
    }
    
    private boolean isWritable(char caracter){
        if (Character.isDigit(caracter)||caracter == '.')
            return true;
        return false;
    }
    
    private boolean isOperation(char caracter){
        if(caracter == '-' || caracter == '+' || caracter == '*' || caracter == '/')
            return true;
        return false;
    }
    
    private void operation(char caracter){  //Si el operando tiene algo entonces sigue haciendo la operacion
        if(operando == Character.MIN_VALUE){
            this.calculadora.setOperando1(pantalla.getText());
            setOperando(caracter);
            pantalla.clear();
        }
        else{
            String opBitacora = "";
            String preRes = this.calculadora.getResultado();
            String impresion = "";
            this.calculadora.setResultado(pantalla.getText());
            switch(operando){
                case '-':
                     impresion = calculadora.resta();
                     break;
                case '+':
                     impresion = calculadora.suma();
                     break;
                case '*':
                     impresion = calculadora.mult();
                     break;
                case '/':
                     impresion = calculadora.div();
                     break;
                default:
                    pantalla.setText("Fatal Error");
            }
            this.calculadora.setResultado(impresion);
            pantalla.clear();
            pantalla.setText(impresion);
            opBitacora = preRes + " " + operando + calculadora.getOperando1() + " = " + impresion;
            agregarABitacora(opBitacora);
            calculadora.clear();
            clearOperando();
        }
    }
    
    private void setOperando(char operando) {//GUI
        this.operando = operando;
    }
    
    private void clearOperando(){//GUI
        this.operando = Character.MIN_VALUE;
    }
    
    private void desactivarBotones(JButton array[]){
        for (int i = 0; i < array.length; i++) {
            array[i].setEnabled(false);
        }
    }
    
    private void activarBotones(JButton array[]){
        for (int i = 0; i < array.length; i++) {
            array[i].setEnabled(true);
        }    
    }
    
    private void clear(){
        pantalla.clear();
        calculadora.clear();
    }
    
    private void memory(){
        String opBitacora;    
        calculadora.setResultado(pantalla.getText());
        calculadora.memory();
        opBitacora = "M+ " + calculadora.getResultado() + " > " + Arrays.toString(calculadora.getMemoria());
        System.out.println(opBitacora);
        agregarABitacora(opBitacora);
    }
    
    private void agregarABitacora(String opBitacora){
        calculadora.getBitacora().saveData(opBitacora);
    }

    private void equal() {
        switch(calculadora.getModo()){
            case BINARIO:
                this.calculadora.setResultado(pantalla.getText());
                pantalla.clear();
                String impresion =calculadora.binrio();
                pantalla.setText(impresion);
                agregarABitacora("Binario: "+this.calculadora.getResultado()+"="+impresion);
                break;
            case PRIMO:
                this.calculadora.setResultado(pantalla.getText());
                pantalla.clear();
                String impresionPrimo = calculadora.primo();
                pantalla.setText(impresionPrimo);
                agregarABitacora("Primo: "+this.calculadora.getResultado()+"="+impresionPrimo);
                break;
            case DECIMAL:
                operation(operando);
        }
    }
    
}
