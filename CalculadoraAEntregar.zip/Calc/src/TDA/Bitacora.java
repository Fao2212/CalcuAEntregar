/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TDA;

import java.io.Serializable;

/**
 *
 * @author Fernando Alvarez
 */
public class Bitacora implements Serializable
{
    private String mensaje;

    public Bitacora() {
        this.mensaje = "";
        cargarBitacora();
    }

    public String getMensaje() {
        return mensaje;
    }
    
    public void agregarABitcora(String nuevaLinea){
        this.mensaje = this.mensaje +"\n"+ nuevaLinea + "\n" + "--------------------------------";
        
    }   
    
    public void cargarBitacora(){
        Bitacora bitacora = (Bitacora)FileManager.readObject("BitacoraCalculadora.txt");
        if(bitacora == null){
            crearArchivoBitacora();
        }
        else{
            this.mensaje = bitacora.mensaje;
        }
    }
    
    private void crearArchivoBitacora(){
        FileManager.writeObject(this,"BitacoraCalculadora.txt");
    }
    
    public void saveData (String mensaje) {
        agregarABitcora(mensaje);
        FileManager.writeObject(this, "BitacoraCalculadora.txt");
    }

}
