/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TDA;

/**
 *
 * @author Fernando Alvarez
 */
public class Operaciones {
        public static float suma(float operando1,float operando2){
        return operando1 + operando2;
    }
    
    public static float resta(float operando1,float operando2){
        return operando1 - operando2;
    }    
    
    public static float mult(float operando1,float operando2){
        return operando1 * operando2;
    }   
    
    public static float div(float operando1,float operando2){
        return operando1 / operando2;
    }   
    
    public static float promedio(float array[],float largo){
        
        float resul;
        resul = 0;
        for (int i = 0; i < array.length; i++) {
            resul += array[i];
        }
        return resul / largo;
    }
    
    public static String binario(int operando1){
        
        if (operando1 != 0){
            return binario(operando1/2) + String.valueOf(operando1%2);
        }
        else
            return "";
    }
    
    public static boolean isPrimo(int operando1){
        if(operando1 == 1 | operando1 == 0)
            return false;
        else{
            for (int i = 2; i < operando1; i++) {
                if (operando1%i == 0)
                    return false;
        }
            return true;
        }
    }
}
