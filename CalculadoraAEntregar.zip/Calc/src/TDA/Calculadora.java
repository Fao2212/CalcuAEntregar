/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TDA;

/**
 *
 * @author Fernando Alvarez
 */
public class Calculadora {
    
    private Bitacora bitacora;
    private Modo modo;
    private float memoria[];
    private String resultado;
    private String operando1;
    private int space;
    private float lenght;
    
    public Calculadora(){
        init();
    }
    
    public void init(){
        this.bitacora = new Bitacora();
        this.modo = modo.DECIMAL;
        this.memoria = new float[11];
        this.resultado = "";
        this.operando1 = "";
        this.space = 0;
    }

    public Bitacora getBitacora() {
        return bitacora;
    }

    public void setBitacora(Bitacora bitacora) {
        this.bitacora = bitacora;
    }

    public Modo getModo() {
        return modo;
    }

    public void setModo(Modo modo) {
        this.modo = modo;
    }

    public float getLenght() {
        return lenght;
    }

    public void setLenght(float lenght) {
        this.lenght = lenght;
    }
    
    private boolean sintaxError(){
        return ("".equals(resultado)||"".equals(operando1)||"Sintax ERROR".equals(resultado));
    }
    
    public int getSpace() {
        return space;
    }

    public void setSpace(int space) {
        this.space = space;
    }
    
    public float[] getMemoria() {
        return memoria;
    }

    public void setMemoria(float[] memoria) {
        this.memoria = memoria;
    }

    public String getResultado() {
        return resultado;
    }

    public void setResultado(String resultado) {
        this.resultado = resultado;
    }

    public String getOperando1() {
        return operando1;
    }

    public void setOperando1(String operando1) {
        this.operando1 = operando1;
    }
    
    private float toFloat(String operando){
        return Float.valueOf(operando);
    }
    
    private String fToString(float operando){
        return String.valueOf(operando);
    }
    
    private int toInt(String operando){
        return Integer.valueOf(operando);
    }
    
    private String bToString(boolean operando){
        return String.valueOf(operando);
    }
    
    public String suma (){//Considerar los numeros que se pueen usar y el punto cambiar a double
        if (sintaxError())
            return "Sintax ERROR";
        else{
            String res = fToString(Operaciones.suma(toFloat(resultado),toFloat(operando1)));
            this.resultado = res;
            return res;
        }
    }
    
    public String resta (){
        if (sintaxError())
            return "Sintax ERROR";
        else{
            String res = fToString(Operaciones.resta(toFloat(operando1),toFloat(resultado)));
            this.resultado = res;
            return res;
        }
    }
    
    public String mult (){
        if (sintaxError())
            return "Sintax ERROR";
        else{
            String res = fToString(Operaciones.mult(toFloat(resultado),toFloat(operando1)));
            this.resultado = res;
            return res;
        }
    }
    
    public String div (){
        if (!"0".equals(operando1)){
            if (sintaxError())
                return "Sintax ERROR";
            else{
                String res = fToString(Operaciones.div(toFloat(operando1),toFloat(resultado)));
                this.resultado = res;
                return res;
            }
        }
        else
            return "Math ERROR";
    }
    
    public String promedio (){
        if (0 != space){
            String res = fToString(Operaciones.promedio(memoria,lenght));
            this.resultado = res;
            return res;
        }
        else
            return "Memoria Vacia";
    }
    
    public String binrio (){
        if (!"".equals(resultado)){
            String res = Operaciones.binario(toInt(resultado));
            this.resultado = res;
            return res;
        }
        else
            return "Sintax ERROR";
    }
    
    public String primo (){
        if (!"".equals(resultado)){
            String res = bToString(Operaciones.isPrimo(toInt(resultado)));
            this.resultado = res;
            return res;
        }
        else
            return "Sintax ERROR";
    }
    
    private void nextSpace(){
        if (space < 10)
            space += 1;
        else
            space = 1;
    }
    
    public void memoryStart(){
        if (0 == space)
            space += 1;
    }
    
    public void memory (){
        if(!"".equals(resultado)){
            memoryStart();
            memoria[space]=toFloat(resultado);
            lenght += 1;
            nextSpace();
        }
    }
    
    public void showMemory(){
        for (int i = 0; i < memoria.length; i++) {
            System.out.println(memoria[i]);
        }
        System.out.println("-------------------------");
    }

    public String neg() {
        if ("".equals(resultado))
            return "Sintax ERROR";
        else{
            String res = fToString(Operaciones.mult(toFloat(resultado),-1));
            this.resultado = res;
            return res;
        }
    }
    public void cambiarModo(Modo modo){
        this.modo = modo;
    }

    public void clear() {
        this.operando1 = "";
    }
    public enum Modo{
        PRIMO,BINARIO,DECIMAL
    }
}

